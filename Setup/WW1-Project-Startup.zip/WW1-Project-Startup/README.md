# WW1-Project
repository for team 3's Enterprise pro project

## To Install:
1. Download the repository and unzip it.
2. Keep BIG RED BUTTON.bat close to close the program if needed.
3. Run Setup/installer.bat
4. Run Start Database Viewer.bat on desktop to start the program.
5. its working if you see a 404 error in json format.